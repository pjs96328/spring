package com.example.webapp.login;

import com.example.webapp.member.MemberDTO;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MapperTests {
//    @Autowired
//    MemberMapper memberMapper;
//
//    @Test
//    public void testinsert(){
//        MemberDTO m1 = new MemberDTO();
//        m1.setId("pjs");
//        m1.setName("park");
//        m1.setPhone("01011");
//        System.out.println(m1);
//        memberMapper.insertMember(m1);
//    }
}
