package com.example.webapp.wishlist;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository

public interface WishlistRepository extends JpaRepository<Wishlist, Long> {
    List<Wishlist> findByUserId(Long userId);
    Wishlist findByUserIdAndProductId(Long userId, Long productId);
    Wishlist findByProductId(Long productId);

}
