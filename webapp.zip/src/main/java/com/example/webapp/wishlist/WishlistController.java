package com.example.webapp.wishlist;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/wishlist")
public class WishlistController {
    @Autowired
    private WishlistService wishlistService;
    @Autowired
    private User user;
    @Autowired
    private UserRepository userRepository;
    @GetMapping
    public String mainpage(){
        return "page";
    }
//    @GetMapping
//    public String wishlistpage(HttpServletRequest request)throws Exception{
//        HttpSession session = request.getSession();
//        Long userId= user.getId();
//        session.setAttribute("Id", userId);
//        System.out.println(session.getAttribute("id"));
//        return "page";
//    }
//    @GetMapping("/user/{userId}")
//    public String viewwishlist(@PathVariable Long userId, Model model){
//        model.addAttribute("wishlist", wishlistService.getWishllist(userId));
//        return "wishlist";
//    }





//    @PostMapping("/toggle")
//    public String togglewishlist(@PathVariable Long userId, @RequestParam Long productId, Model model){
//        String message = wishlistService.toggleWishlist(userId, productId);
//        model.addAttribute("status", "success");
//        model.addAttribute("message", message);
//        return "wishlist";
//    }
//    @GetMapping("/user/{userId}")
//    public String getwishlist(@RequestParam Long userId, @RequestParam Long productId, Model model){
//        List<Product> wishlist = wishlistService.getWishllist(userId);
//        model.addAttribute("status", "success");
//        model.addAttribute("message", "찜 목록");
//        model.addAttribute("wishlist", wishlist);
//        return "user";
//    }
}
