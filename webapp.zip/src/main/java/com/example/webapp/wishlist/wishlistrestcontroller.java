package com.example.webapp.wishlist;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/wishlist")
public class wishlistrestcontroller {
    @Autowired
    WishlistService wishlistService;
    @PostMapping("/add")
    public ResponseEntity<WishlistResponse<String>> addwishlist(@RequestParam Long userId, @RequestParam Long productId) {
        String message = wishlistService.toggleWishlist(userId, productId);
        return new ResponseEntity<>(new WishlistResponse<>(message, null), HttpStatus.OK);
    }
    @GetMapping("/user/{userId}")
    public ResponseEntity<WishlistResponse<List<Product>>> getuserwishlist(@PathVariable Long userId){
        List<Product> wishlist = wishlistService.getWishllist(userId);
        return new ResponseEntity<>(new WishlistResponse<>( "찜 목록", wishlist), HttpStatus.OK);
    }
    @PostMapping ("/user/{userId}/delete")
    public ResponseEntity<WishlistResponse<String>> deletewishlist(@PathVariable Long userId, @RequestParam Long productId){
        String message = wishlistService.deletewishlist(userId, productId);
        return new ResponseEntity<>(new WishlistResponse<>(message, ""), HttpStatus.OK);
    }
}
