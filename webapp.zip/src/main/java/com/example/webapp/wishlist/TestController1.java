package com.example.webapp.wishlist;

import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/test")
public class TestController1 {
    public HttpSession httpSession;
    @PostMapping
    public String test2(HttpSession httpSession, @RequestBody String name){
        httpSession.setAttribute("user", name);
        return name;
    }
    @GetMapping
    public String test3(HttpSession httpSession){
        String name = (String) httpSession.getAttribute("user");
        return name;
    }
}
