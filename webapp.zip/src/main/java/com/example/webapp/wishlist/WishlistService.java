package com.example.webapp.wishlist;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WishlistService {
    @Autowired
    private WishlistRepository wishlistRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ProductRepository productRepository;

    @Transactional
    public String toggleWishlist(Long userId, Long productId){
        User user = userRepository.findById(userId).orElseThrow(()-> new RuntimeException());
        Product product = productRepository.findById(productId).orElseThrow(()-> new RuntimeException("product not found"));

        Wishlist wishlist = wishlistRepository.findByUserIdAndProductId(userId, productId);
        if(wishlist != null){
            wishlistRepository.delete(wishlist);
            return "지워짐";
        }else {
            Wishlist newwishlist = new Wishlist();
            newwishlist.setUser(user);
            newwishlist.setProduct(product);
            wishlistRepository.save(newwishlist);
            return "저장됨";
        }

    }
    @Transactional
    public String deletewishlist(Long userId, Long productId){
        Product product = productRepository.findById(productId).orElseThrow(()-> new RuntimeException("product not found"));
        Wishlist wishlist = wishlistRepository.findByProductId(productId);
        if (wishlist != null){
            wishlistRepository.delete(wishlist);
            return "지워짐";
        }else {
            return "찜 목록에 없음";
        }
    }



    @Transactional
    public List<Product> getWishllist(Long userId){
        User user = userRepository.findById(userId).orElseThrow(()-> new RuntimeException());
        return wishlistRepository.findByUserId(userId).stream().map(Wishlist::getProduct).collect(Collectors.toList());
    }
}
