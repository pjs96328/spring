package com.example.webapp.service;

import com.example.webapp.dto.LikeResponseDTO;
import com.example.webapp.entity.Board;
import com.example.webapp.entity.Like;
import com.example.webapp.entity.Member;
import com.example.webapp.repository.BoardRepository;
import com.example.webapp.repository.LikeRepository;
import com.example.webapp.repository.MemberRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class LikeService {
    @Autowired
    private final BoardService boardService;
    @Autowired
    private final LikeRepository likeRepository;
    @Autowired
    private final MemberRepository memberRepository;
    @Autowired
    private final BoardRepository boardRepository;

    @Transactional
    public void insert(LikeResponseDTO likeResponseDTO) throws Exception {
        Member member = memberRepository.findById(LikeResponseDTO.getMemberId()).orElseThrow(() -> new NotFoundException("not found memberid" + LikeResponseDTO.getMemberId()));
        Board board = boardRepository.findById(LikeResponseDTO.getMemberId()).orElseThrow(() -> new NotFoundException("not found memberid" + LikeResponseDTO.getMemberId()));
        if(likeRepository.existsByMemberAndBoard(member,board).isPresent()){
            throw new Exception();
        }
        Like like = Like.builder()
                .board(board)
                .member(member)
                .build();
        likeRepository.save(like);
        boardRepository.addLikeCount(board.getBoardid());
    }
    @Transactional
    public void delete(LikeResponseDTO likeResponseDTO) throws NotFoundException {
        Member member = memberRepository.findById(LikeResponseDTO.getMemberId()).orElseThrow(() -> new NotFoundException("not found memberid" + LikeResponseDTO.getMemberId()));
        Board board = boardRepository.findById(LikeResponseDTO.getMemberId()).orElseThrow(() -> new NotFoundException("not found memberid" + LikeResponseDTO.getBoardId()));
        Like like = likeRepository.existsByMemberAndBoard(member,board).orElseThrow(() -> new NotFoundException("not found memberid"));
        likeRepository.delete(like);
        boardRepository.subLikeCount(board.getBoardid());
    }
//    public void addLike(Long boardId, Member member){
//        Board board = boardService.findBoardid(boardId);
//        Member member1 = memberRepository.findById(member.getMemberId()).orElseThrow(() -> new RuntimeException("Member not found"));
//        if (!likeRepository.existsByMemberAndBoard(member1, board)){
//            board.setLikeCount(board.getLikeCount()+1);
//            likeRepository.save(new Like(member1,board));
//        }
//        else {
//            board.setLikeCount(board.getLikeCount()-1);
//            likeRepository.deleteByMemberAndBoard(member1,board);
//        }
//        boardRepository.save(board);
//    }
}
