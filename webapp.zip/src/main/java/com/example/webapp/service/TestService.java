package com.example.webapp.service;

import com.example.webapp.dto.testDto;
import com.example.webapp.entity.testEntity;
import com.example.webapp.repository.TestRepository;
import org.springframework.stereotype.Service;

@Service
public class TestService {
    private final TestRepository testRepository;

    public TestService(TestRepository testRepository) {
        this.testRepository = testRepository;
    }
    public void savetest(testDto testdto){
        testEntity testentity = testEntity.totestEntity(testdto);
        testRepository.save(testentity);
    }
}
