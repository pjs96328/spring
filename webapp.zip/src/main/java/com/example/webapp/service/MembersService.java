package com.example.webapp.service;

import com.example.webapp.dto.MemberDTO;
import com.example.webapp.entity.MemberEntity;
import com.example.webapp.repository.MembersRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MembersService {
    private final MembersRepository membersRepository;

    public MembersService(MembersRepository membersRepository) {
        this.membersRepository = membersRepository;
    }

    public void save(MemberDTO memberDTO){
        MemberEntity memberEntity = MemberEntity.toMemberEntity(memberDTO);
        membersRepository.save(memberEntity);
    }
    public MemberDTO login(MemberDTO memberDTO){
        Optional<MemberEntity> byMemberEmail = membersRepository.findByMemberEmail(memberDTO.getMemberEmail());
        if(byMemberEmail.isPresent()){
            MemberEntity memberEntity = byMemberEmail.get();
            if (memberEntity.getMemberPassword().equals(memberDTO.getMemberPassword())){
                MemberDTO dto = memberDTO.toMemberDTO(memberEntity);
                return dto;
            }else {
                return null;
            }
        }else{
            return null;
        }
    }
}
