package com.example.webapp.service;

import com.example.webapp.Exeptiona.BusinessLogicException;
import com.example.webapp.Exeptiona.ExceptionCode;
import com.example.webapp.dto.BoardDTO;
import com.example.webapp.dto.BoardPatchDTO;
import com.example.webapp.dto.BoardResponseDTO;
import com.example.webapp.entity.Board;
import com.example.webapp.repository.BoardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BoardService {
    @Autowired
    private final BoardRepository boardRepository;
    private final MemberService memberService;

    public Long createBoard(BoardDTO boardDTO) {
        Board board = new Board();
        board.setTitle(boardDTO.getTitle());
        board.setContent(boardDTO.getContent());

        return boardRepository.save(board).getBoardid();
    }

    public Long updateBoard(BoardPatchDTO boardPatchDTO, Long boardid) {
        Board board = findBoardid(boardid);
        board.setTitle(boardPatchDTO.getTitle());
        board.setContent(boardPatchDTO.getContent());
        return boardRepository.save(board).getBoardid();

    }

    public Board findBoardid(Long boardid) {
        return boardRepository.findById(boardid).orElseThrow(() -> new BusinessLogicException(ExceptionCode.Board_NOT_FOUND));

    }
    public void deleteBoard(Long boardid){
        findBoardid(boardid);
        boardRepository.deleteById(boardid);
    }
    public BoardResponseDTO findByBoardid(Long boardid){
        Board board = findBoardid(boardid);
        board.setBoardCount(board.getBoardCount() + 1);
        boardRepository.save(board);
        return BoardResponseDTO.FindFromBoard(board);
    }

    public Page<BoardResponseDTO> findAllBoards(Pageable pageable){
        Page<Board> boardEntities = boardRepository.findAll(pageable);
        return boardEntities.map(BoardResponseDTO::FindFromBoard);
    }



}
