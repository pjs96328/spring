package com.example.webapp.service;

import com.example.webapp.Exeptiona.BusinessLogicException;
import com.example.webapp.Exeptiona.ExceptionCode;
import com.example.webapp.dto.MemberPatchDTO;
import com.example.webapp.dto.MemberPostDTO;
import com.example.webapp.dto.MemberResponseDTO;
import com.example.webapp.entity.Member;
import com.example.webapp.repository.MemberRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;
    private final PasswordEncoder passwordEncoder;
    private final CustomAuthorityUtils customAuthorityUtils;

    public Member findMemberId(Long memberId) {
        return memberRepository.findById(memberId).orElseThrow(()-> new BusinessLogicException(ExceptionCode.Board_NOT_FOUND));
    }
    public Member findByEmail(String email){
        return memberRepository.findByEmail(email).orElseThrow(()-> new BusinessLogicException(ExceptionCode.Board_NOT_FOUND));
    }
    public Optional<Member> displayNickname(String nickname){
        return memberRepository.findByNickname(nickname);
    }

    @Transactional
    public Long createMember(MemberPostDTO memberPostDTO){
        Member member = new Member();
        member.setEmail(memberPostDTO.getEmail());
//        member.setPassword(memberPostDTO.getPassword());
        member.setPassword(passwordEncoder.encode(memberPostDTO.getPassword()));
        member.setRoles(customAuthorityUtils.createRoles(memberPostDTO.getEmail()));
        member.setNickname(memberPostDTO.getNickname());

        return memberRepository.save(member).getMemberId();
    }

    public Long updateMember(MemberPatchDTO memberPostDTO, Long memberId){
        Member member = findMemberId(memberId);
        member.setEmail(memberPostDTO.getEmail());
        member.setPassword(memberPostDTO.getPassword());
        member.setNickname(memberPostDTO.getNickname());

        return memberRepository.save(member).getMemberId();
    }
    public MemberResponseDTO findByMemberId(Long memberId){
        Member member = findMemberId(memberId);
        return MemberResponseDTO.FindFromMember(member);
    }
    public void deleteMember(Long memberId){
        findMemberId(memberId);
        memberRepository.deleteById(memberId);
    }
    public MemberResponseDTO login(MemberResponseDTO memberResponseDTO){
        Optional<Member> Bymemberemail = memberRepository.findByEmail(memberResponseDTO.getEmail());
        if (Bymemberemail.isPresent()){
            Member member = Bymemberemail.get();
            if (member.getPassword().equals(memberResponseDTO.getPassword())){
                MemberResponseDTO dto = MemberResponseDTO.toMemberResponseDTO(member);
                return dto;
            }else{
                return null;
            }
        }else {
            return null;
        }
    }
    public boolean verifypassword(MemberResponseDTO memberResponseDTO){
        Member member = memberRepository.findByEmail(memberResponseDTO.getEmail()).orElseThrow(()->new RuntimeException());
        return passwordEncoder.matches(memberResponseDTO.getPassword(), member.getPassword());
    }
}
