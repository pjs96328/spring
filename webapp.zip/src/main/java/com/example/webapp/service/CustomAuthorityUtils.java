package com.example.webapp.service;

import com.example.webapp.wishlist.Roles;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import javax.management.relation.Role;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class CustomAuthorityUtils {
    //email기반으로 권한 부여
    public List<String> createRoles(String email){
        if (email.endsWith("@admin.com")){
            return List.of("ROLE_ADMIN", "ROLE_USER");
        }else {
            return List.of("ROLE_USER");
        }
    }
    public List<GrantedAuthority> createAuthority(List<String> roles){
        return roles.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
    }
    public Set<Roles> createRole(String username){
        Set<Roles> roles = new HashSet<>();
        if (username.endsWith("@admin")){
            roles.add(new Roles("role_admin"));
            roles.add(new Roles("role_user"));
        }else {
            roles.add(new Roles("role_user"));
        }
        return roles;
    }
}
