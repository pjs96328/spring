package com.example.webapp;

import com.example.webapp.entity.Member;
import com.example.webapp.repository.MemberRepository;
import com.example.webapp.service.MemberService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

public class SayHelloController {
    public static void main(String[] args) {
        MemberService memberService;
        Member member = new Member();
        MemberRepository memberRepository;
        System.out.println(member.getMemberId());
    }

}
