package com.example.webapp.entity;

import com.example.webapp.dto.testDto;
import jakarta.persistence.*;

@Entity
@Table(name = "member_test")
public class testEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "user")
    private String testuser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "name")
    private String testname;

    public String getTestuser() {
        return testuser;
    }

    public void setTestuser(String testuser) {
        this.testuser = testuser;
    }

    public String getTestname() {
        return testname;
    }

    public void setTestname(String testname) {
        this.testname = testname;
    }
    public static testEntity totestEntity(testDto testdto){
        testEntity testentity = new testEntity();
        testentity.setId(testdto.getId());
        testentity.setTestname(testdto.getTestname());
        testentity.setTestuser(testdto.getTestuser());
        return testentity;
    }
}
