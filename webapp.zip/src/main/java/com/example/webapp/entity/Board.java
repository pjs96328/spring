package com.example.webapp.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "board")
@NoArgsConstructor
public class Board {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "board_id")
    private long boardid;
    private String title;
    private String content;
    private Integer boardCount = 0;

    private int likeCount =0;
    @ManyToOne
    @JoinColumn(name = "member_id")
    private Member member;

    public void addLikeCount(){
        this.likeCount++;
    }
    public void subLikeCount(){
        this.likeCount--;
    }



}
