package com.example.webapp.controller;

import com.example.webapp.dto.MemberDTO;
import com.example.webapp.dto.testDto;
import com.example.webapp.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class TestController {
    @Autowired
    private final TestService testService;

    public TestController(TestService testService) {
        this.testService = testService;
    }

    @GetMapping(value = "/testpage")
    public String testform(){
        return "testpage";
    }
    @PostMapping("/testpage")
    public String testsave(@ModelAttribute testDto testdto){
        testService.savetest(testdto);
        return "testpage";
    }
}
