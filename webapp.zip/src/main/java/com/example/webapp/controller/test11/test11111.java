package com.example.webapp.controller.test11;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/test11")
public class test11111 {
    @GetMapping
    public String test11(){
        return "test111";
    }
}
