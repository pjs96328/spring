package com.example.webapp.controller;

import com.example.webapp.dto.MemberPatchDTO;
import com.example.webapp.dto.MemberPostDTO;
import com.example.webapp.dto.MemberResponseDTO;
import com.example.webapp.entity.Member;
import com.example.webapp.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.ErrorResponseException;
import org.springframework.web.bind.annotation.*;
@RestController
@RequiredArgsConstructor
public class MemberController {
    @Autowired
    private final MemberService memberService;
    @PostMapping("/member/create")
    public ResponseEntity<Long> createMember(@RequestBody MemberPostDTO memberPostDto) {
        Long memberId = memberService.createMember(memberPostDto);
        return new ResponseEntity<>(memberId, HttpStatus.CREATED);
    }

    @PatchMapping("/member/{memberId}/update")
    public ResponseEntity<Long> updateMember(@RequestBody MemberPatchDTO memberPatchDto, @PathVariable Long memberId) {
        Long updatedMemberId = memberService.updateMember(memberPatchDto, memberId);
        return new ResponseEntity<>(updatedMemberId, HttpStatus.OK);
    }

    @GetMapping("/member/{memberId}")
    public ResponseEntity<MemberResponseDTO> findByMemberId(@PathVariable Long memberId) {
        MemberResponseDTO memberResponseDto = memberService.findByMemberId(memberId);
        return new ResponseEntity<>(memberResponseDto, HttpStatus.OK);
    }

    @DeleteMapping("/member/{memberId}")
    public ResponseEntity<String> deleteMember(@PathVariable Long memberId) {
        memberService.deleteMember(memberId);
        return new ResponseEntity<>("Member deleted", HttpStatus.OK);
    }

    @PostMapping("/member/login")
    public String login(@RequestBody MemberResponseDTO memberResponseDTO){
//        MemberResponseDTO loginresult = memberService.login(memberResponseDTO);
        boolean  is = memberService.verifypassword(memberResponseDTO);
        if (is){
            return "로그인 성공";
        }else {
            return "로그인 실패";
        }
    }

}
