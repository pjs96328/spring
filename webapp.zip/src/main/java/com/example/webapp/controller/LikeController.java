package com.example.webapp.controller;

import com.example.webapp.dto.LikeResponseDTO;
import com.example.webapp.entity.Member;
import com.example.webapp.service.LikeService;
import com.example.webapp.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.javassist.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Positive;


@Slf4j
@RestController
@RequestMapping("/likes")
@RequiredArgsConstructor
public class LikeController {
    private final LikeService likeService;

    @PostMapping("/{boardid}")
    public ResponseEntity<?> insert (@RequestBody @Valid LikeResponseDTO likeResponseDTO) throws Exception {
        likeService.insert(likeResponseDTO);
        return ResponseEntity.ok().build();
    }
    @DeleteMapping("/{boardid}")
    public ResponseEntity<?> delete(@RequestBody @Valid LikeResponseDTO likeResponseDTO) throws NotFoundException {
        likeService.delete(likeResponseDTO);
        return ResponseEntity.ok().build();
    }


}
