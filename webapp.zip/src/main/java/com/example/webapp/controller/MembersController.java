package com.example.webapp.controller;

import com.example.webapp.dto.MemberDTO;
import com.example.webapp.service.MembersService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class MembersController {
    private final MembersService membersService;

    public MembersController(MembersService membersService) {
        this.membersService = membersService;
    }

    @GetMapping("/main")
    public String mainForm(){
        return "index";
    }
    @GetMapping("/save")
    public String saveform(){
        return "save";
    }
    @PostMapping("/save")
    public String save(@ModelAttribute MemberDTO memberDTO){
        System.out.println(memberDTO);
        membersService.save(memberDTO);
        return "login2";
    }
    @GetMapping("/login2")
    public String loginform(){
        return "login2";
    }
    @PostMapping("/login2")
    public String login(@ModelAttribute MemberDTO memberDTO, HttpSession session){
        MemberDTO loginResult = membersService.login(memberDTO);
        if(loginResult != null){
            session.setAttribute("loginEmail", loginResult.getMemberEmail());
            return "main";
        }else {
            session.setAttribute("errorMessage", "아이디 혹은 비밀번호가 틀립니다.");
            return "login2";
        }
    }

}
