package com.example.webapp.controller;

import com.example.webapp.dto.*;
import com.example.webapp.entity.Board;
import com.example.webapp.entity.Member;
import com.example.webapp.service.BoardService;
import com.example.webapp.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/board")
public class BoardController {
    @Autowired
    private final BoardService boardService;
    private final MemberService memberService;

    @PostMapping
    public ResponseEntity postBoard(@RequestBody @Validated BoardDTO boardDTO){
        Long boardid = boardService.createBoard(boardDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(boardid);
    }
    @PatchMapping("/{boardid}")
    public ResponseEntity patchBoard(@PathVariable("boardid")Long boardid,
                                     @RequestBody @Validated BoardPatchDTO boardPatchDTO){
        boardService.updateBoard(boardPatchDTO, boardid);
        return ResponseEntity.status(HttpStatus.OK).body(boardid);
    }
    @DeleteMapping("/{boardid}")
    public ResponseEntity deleteBoard(@PathVariable("boardid") Long boardid){
        boardService.deleteBoard(boardid);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
    @GetMapping("/{boardid}")
    public ResponseEntity getboard(@PathVariable("boardid") Long boardid){
        BoardResponseDTO boardResponseDTO = boardService.findByBoardid(boardid);
        return ResponseEntity.status(HttpStatus.OK).body(boardResponseDTO);
    }
    @GetMapping
    public ResponseEntity<Page<BoardResponseDTO>> getAllBoards(
            @RequestParam(value = "page", defaultValue = "1")int page,
            @RequestParam(value = "size", defaultValue = "5")int size){
        Pageable pageable = PageRequest.of(page - 1, size);
        Page<BoardResponseDTO> boards = boardService.findAllBoards(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(boards);
    }

}
