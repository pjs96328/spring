package com.example.webapp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class MemberPatchDTO {
//
    private String email;
    private String password;
    private String nickname;
}
