package com.example.webapp.dto;

import com.example.webapp.entity.Board;
import com.example.webapp.entity.Member;
import com.example.webapp.entity.MemberEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@AllArgsConstructor
public class BoardResponseDTO {
    private Long boardid;
    private String title;
    private String content;
    private Integer boardCount;
    private Integer likeCount;
    private String name;



    public static BoardResponseDTO FindFromBoard(Board board) {
        String name = board.getMember().getNickname();
        return new BoardResponseDTO(
                board.getBoardid(),
                board.getTitle(),
                board.getContent(),
                board.getBoardCount(),
                board.getLikeCount(),
                name


        );

    }
}
