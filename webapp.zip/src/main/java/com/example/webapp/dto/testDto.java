package com.example.webapp.dto;

import com.example.webapp.entity.testEntity;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class testDto {
    private Long id;
    private String testuser;
    private String testname;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "testDto{" +
                "id=" + id +
                ", testuser='" + testuser + '\'' +
                ", testname='" + testname + '\'' +
                '}';
    }

    public String getTestuser() {
        return testuser;
    }

    public void setTestuser(String testuser) {
        this.testuser = testuser;
    }

    public String getTestname() {
        return testname;
    }

    public void setTestname(String testname) {
        this.testname = testname;
    }
    public testDto totestDto(testEntity testentity){
        testDto testdto = new testDto();
        testdto.setId(testentity.getId());
        testdto.setTestname(testentity.getTestname());
        testdto.setTestuser(testentity.getTestuser());
        return testdto;
    }
}
