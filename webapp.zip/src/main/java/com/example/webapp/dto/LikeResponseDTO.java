package com.example.webapp.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class LikeResponseDTO {
    private static Long memberId;
    private static Long boardId;

    public static Long getMemberId() {
        return memberId;
    }
    public static Long getBoardId(){
        return boardId;
    }
}
