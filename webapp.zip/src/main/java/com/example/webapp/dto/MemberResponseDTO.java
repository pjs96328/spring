package com.example.webapp.dto;

import com.example.webapp.entity.Member;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter@Setter
@AllArgsConstructor
public class MemberResponseDTO {
    private Long memberId;
    private String email;
    private String nickname;
    private String password;

    public MemberResponseDTO(Long memberId) {
        this.memberId = memberId;
    }



    public static MemberResponseDTO FindFromMember(Member member) {
        return new MemberResponseDTO(
        member.getMemberId(),
        member.getEmail(),
        member.getNickname(),
        member.getPassword()
        );
    }

    public MemberResponseDTO() {
    }

    public static MemberResponseDTO toMemberResponseDTO(Member member){
        MemberResponseDTO memberResponseDTO = new MemberResponseDTO();
        memberResponseDTO.setMemberId(member.getMemberId());
        memberResponseDTO.setEmail(member.getEmail());
        memberResponseDTO.setPassword(member.getPassword());
        memberResponseDTO.setNickname(member.getNickname());
        return memberResponseDTO;

    }
}
