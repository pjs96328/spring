package com.example.webapp.repository;

import com.example.webapp.entity.testEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TestRepository extends JpaRepository<testEntity, Long> {
}
