package com.example.webapp.repository;

import com.example.webapp.entity.Board;
import com.example.webapp.entity.Like;
import com.example.webapp.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LikeRepository extends JpaRepository<Like, Long> {
    Optional<Like> existsByMemberAndBoard(Member member, Board board);
    void deleteByMemberAndBoard(Member member, Board board);
}
