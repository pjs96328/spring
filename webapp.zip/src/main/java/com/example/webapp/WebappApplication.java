package com.example.webapp;

import com.example.webapp.entity.Member;
import com.example.webapp.wishlist.RoleRepository;
import com.example.webapp.wishlist.Roles;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class WebappApplication {
	@Autowired
	private RoleRepository roleRepository;
	public static void main(String[] args) {SpringApplication.run(WebappApplication.class, args);}
	public void run(String... args)  throws Exception{
		Roles memberROle = new Roles();
		memberROle.setName("role_member");
		roleRepository.save(memberROle);
	}
}
